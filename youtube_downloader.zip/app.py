from flask import Flask, render_template, request, jsonify, send_file
from yt_dlp import YoutubeDL
import os, uuid, datetime

app = Flask(__name__)
DOWNLOAD_DIR = "downloads"
LOG_FILE = "download_logs.txt"

if not os.path.exists(DOWNLOAD_DIR):
    os.makedirs(DOWNLOAD_DIR)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/get_formats', methods=['POST'])
def get_formats():
    url = request.json['url']
    try:
        ydl_opts = {'quiet': True, 'extract_flat': False}
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)

            if 'entries' in info:
                entries = [{
                    'title': entry['title'],
                    'id': entry['id'],
                    'url': entry['webpage_url'],
                    'thumbnail': entry.get('thumbnail')
                } for entry in info['entries']]
                return jsonify({'playlist': True, 'entries': entries, 'title': info.get('title', 'Playlist')})

            formats = []
            for f in info['formats']:
                ftype = 'audio' if f.get('vcodec') == 'none' else 'video'
                formats.append({
                    'format_id': f['format_id'],
                    'ext': f['ext'],
                    'resolution': f.get('resolution') or f.get('height'),
                    'note': f.get('format_note', ''),
                    'filesize': f.get('filesize'),
                    'ftype': ftype
                })

            return jsonify({
                'title': info['title'],
                'thumbnail': info.get('thumbnail'),
                'formats': formats,
                'playlist': False
            })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/download', methods=['POST'])
def download():
    url = request.json['url']
    format_id = request.json.get('format_id', 'bestvideo+bestaudio/best')
    is_thumbnail = request.json.get('thumbnail', False)

    if is_thumbnail:
        try:
            video_id = url.split("v=")[-1].split("&")[0]
            thumb_url = f"https://img.youtube.com/vi/{video_id}/maxresdefault.jpg"
            import requests
            r = requests.get(thumb_url)
            file_path = os.path.join(DOWNLOAD_DIR, f"{video_id}_thumbnail.jpg")
            with open(file_path, 'wb') as f:
                f.write(r.content)
            return send_file(file_path, as_attachment=True)
        except Exception as e:
            return jsonify({'error': str(e)}), 500

    filename = f"{uuid.uuid4()}.%(ext)s"
    output_path = os.path.join(DOWNLOAD_DIR, filename)

    ydl_opts = {
        'format': format_id,
        'outtmpl': output_path,
        'quiet': True,
        'merge_output_format': 'mp4'
    }

    try:
        with YoutubeDL(ydl_opts) as ydl:
            ydl.download([url])

        latest = sorted(os.listdir(DOWNLOAD_DIR), key=lambda x: os.path.getmtime(os.path.join(DOWNLOAD_DIR, x)))[-1]
        file_path = os.path.join(DOWNLOAD_DIR, latest)

        with open(LOG_FILE, 'a') as f:
            f.write(f"{datetime.datetime.now()} - {url} - Format: {format_id}\n")

        return send_file(file_path, as_attachment=True)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
